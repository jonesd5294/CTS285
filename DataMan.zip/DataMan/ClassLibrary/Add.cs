﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Add 
    {
        //Declare Add constructor
        public static int GetAdd(int num1, int num2)
        {
            return num1 + num2;
        }

    }
}
