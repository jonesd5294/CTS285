﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public static class Multiply
    {
        public static int GetMultiply(int int1, int int2)
        {
            return int1 * int2;
        }
    }
}
